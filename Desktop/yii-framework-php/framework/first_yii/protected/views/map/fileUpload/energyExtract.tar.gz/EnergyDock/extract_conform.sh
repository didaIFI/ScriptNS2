#!/bin/bash
#@author : Louacheni Farida
#20-07-2014
#script to extract conformation from dock log

#create directories if they don't exist
WORK_DIR=`pwd`
echo "Extract docking information : `date`"
#extract all docked conformation from dock log file
echo -n "Extracting process......"
#test
#!/bin/bash
grep '^DOCKED' *_*_*.dlg | cut -c9-  > my_docking.pdbqt
ls ZINC*_0*_1OKE.dlg > fileDLG.txt
for DLG in `cat fileDLG.txt`
do
grep ^DOCKED $DLG | cut -c 9-75 > ${DLG%%.*}.pdb
csplit -k -q -f "docking." ${DLG%%.*}.dlg /^ENDMDL/+1 {*}
done
#
for f in `ls docking.[0-9][0-9]`;do
grep ^ATOM $f > $f.pdb
echo END >> $f.pdb
rm $f
done
cut -c-66 my_docking.pdbqt > my_docking.pdb
#split mutlimodel pdbqt
#set a=`grep ENDMDL my_docking.pdbqt | wc -l`
#set b=`expr $a-2`
#csplit -k -s -n 3 -f my_docking  my_docking.pdbqt '/^ENDMDL/+1' '{'$b'}'
echo "splitting done"
#rename docked file to include energy of binding and run information
echo -n "Extracting energies"
for f in docking.[0-9][0-9].pdb
do
set i=`grep "MODEL" $f | sed 's/.dlg:DOCKED://' | awk '{print $1 "_" $3}'`
set j=`grep "Estimated Free" $f | awk '{printf ("%06.2f \n", $9)}' | sed 's/\./#/g'`
set k=`echo "${j}(${i})"`
sed 's/.*DOCKED: //' $f > PDBQT/${k}.pdbqt
echo -n ". "
done
#rm -rf temp????
echo "Extracting done"

#create pdb file with all models
echo -n "Cleaning..........."
sed 's/.*DOCKED: //' my_docking.pdbqt | cut -c-66 > my_docked.pdb
#rm -rf temp.pdbqt

#moving pdb files to pdb directory
#mv PDBQT/*.pdb -t PDB
#echo "Moving files to PDB finish with success"
echo ""
echo "Extraction doking successufully terminated: `date`"

