<?php

/**
 * Wsdl2phpGenerator.php
 *
 * PHP version 5.2+
 *
 * @author Joe Blocher <yii@myticket.at>
 * @copyright 2011 myticket it-solutions gmbh
 * @license New BSD License
 * @package wsdl2php
 * @version 0.5
 */
class Wsdl2phpGenerator extends CCodeGenerator
{
	public $codeModel='application.gii.wsdl2php.Wsdl2phpCode';
}